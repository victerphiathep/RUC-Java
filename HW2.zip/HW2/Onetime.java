
/**
 * Write a description of class Onetime here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Onetime extends Appointment
{
    public Onetime(int a, int b, int c, String description)
    {
        super(a,b,c,description);
        //d=a;
        //m=b;
        //y=c;
        //desc=description;
        
        
    }
    
    public boolean occursOn(int inputd, int inputm, int inputy)
    {
        //check all three 
    }
    
    
}

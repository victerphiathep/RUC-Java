
/**
 * Write a description of class Daily here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Daily extends Appointment
{
    public boolean occursOn(int inputd, int inputm, int inputy)
    {
        //check only d against inputd
    }
}


/**
 * Write a description of class Monthly here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Monthly extends Appointment
{
    // constructor too
    
   public boolean occursOn(int inputd, int inputm, int inputy)
    {
        //check only month
    }
}
